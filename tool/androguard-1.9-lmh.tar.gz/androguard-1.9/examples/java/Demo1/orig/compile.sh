#!/bin/sh

javac Util.java
javac Registry.java
javac Properties.java

exit 0
